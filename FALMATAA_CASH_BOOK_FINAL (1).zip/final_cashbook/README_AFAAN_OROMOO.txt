FALMATAA CASH BOOK – Version 1.1

APPICHA
- Maqaa: FALMATAA CASH BOOK
- Afaan Oromoo
- Offline / Room local database
- Android minSdk 24, targetSdk 35

WANTA XUMURAME
1. Dashboard
2. Galii galmeessuu
3. Baasii galmeessuu
4. Hafe ofumaan shallaguu
5. Baankii fi Harkaa adda baasuu
6. Seenaa galmee
7. Barbaacha
8. Guyyaa filachuu fi guyyaan filter gochuu
9. Edit
10. Delete + mirkaneessa haqaa
11. Gabaasa Har'aa / Torban / Ji'a
12. PIN Lock 4–6 digit, hash SHA-256
13. PIN yeroo app gara background/stop deemu irra deebi'ee gaafachuu
14. Backup JSON
15. Restore JSON + mirkaneessa dura
16. PDF export
17. Excel/CSV export (CSV UTF-8, Excel keessatti banama)
18. Modern Material 3 UI

BUILD
- Project kana Android Studio keessatti bani.
- Gradle Sync godhi.
- Build > Build APK(s) filadhu.
- APK: app/build/outputs/apk/debug/app-debug.apk

Hubachiisa:
Environment kana keessatti Android SDK/Gradle executable hin jiru; kanaaf APK binary as keessatti compile gochuun hin danda'amne. Source project garuu qophaa'ee jira.
