package com.falmataa.cashbook.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Long,
    val type: String,
    val description: String,
    val date: Long,
    val account: String
)

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    fun observeAll(): Flow<List<TransactionEntity>>

    @Insert
    suspend fun insert(t: TransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<TransactionEntity>)

    @Update
    suspend fun update(t: TransactionEntity)

    @androidx.room.Delete
    suspend fun delete(t: TransactionEntity)

    @Query("DELETE FROM transactions")
    suspend fun deleteAll()
}

@Database(entities = [TransactionEntity::class], version = 1, exportSchema = false)
abstract class CashBookDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao

    companion object {
        @Volatile private var INSTANCE: CashBookDatabase? = null

        fun get(context: Context): CashBookDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                CashBookDatabase::class.java,
                "falmataa_cash_book.db"
            ).build().also { INSTANCE = it }
        }
    }
}
