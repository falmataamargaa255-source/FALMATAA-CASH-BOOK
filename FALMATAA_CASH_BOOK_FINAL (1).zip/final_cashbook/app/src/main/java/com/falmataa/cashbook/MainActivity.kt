package com.falmataa.cashbook

import android.app.DatePickerDialog
import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.falmataa.cashbook.data.CashBookDatabase
import com.falmataa.cashbook.data.TransactionDao
import com.falmataa.cashbook.data.TransactionEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class CashBookViewModel(private val dao: TransactionDao) : ViewModel() {
    val transactions = dao.observeAll().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList()
    )

    fun save(t: TransactionEntity) = viewModelScope.launch {
        if (t.id == 0L) dao.insert(t) else dao.update(t)
    }

    fun delete(t: TransactionEntity) = viewModelScope.launch { dao.delete(t) }

    fun clearAndRestore(items: List<TransactionEntity>) = viewModelScope.launch {
        dao.deleteAll()
        dao.insertAll(items)
    }

    fun balance(items: List<TransactionEntity>, account: String? = null): Long =
        items.filter { account == null || it.account == account }
            .sumOf { if (it.type == "Galii") it.amount else -it.amount }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = CashBookDatabase.get(this).transactionDao()
        val vm = ViewModelProvider(this, object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                CashBookViewModel(dao) as T
        })[CashBookViewModel::class.java]
        setContent { MaterialTheme { CashBookApp(vm) } }
    }
}

class PinStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("security", Context.MODE_PRIVATE)

    fun enabled(): Boolean = prefs.getBoolean("pin_enabled", false)
    fun setPin(pin: String) = prefs.edit()
        .putBoolean("pin_enabled", true)
        .putString("pin_hash", hash(pin))
        .apply()
    fun disable() = prefs.edit().clear().apply()
    fun verify(pin: String): Boolean = prefs.getString("pin_hash", "") == hash(pin)

    private fun hash(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(StandardCharsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}

@Composable
fun CashBookApp(vm: CashBookViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val transactions by vm.transactions.collectAsState()
    var unlocked by remember { mutableStateOf(!PinStore(context).enabled()) }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && PinStore(context).enabled()) unlocked = false
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (!unlocked) {
        PinLockScreen { unlocked = true }
        return
    }

    var page by remember { mutableStateOf(0) }
    var edit by remember { mutableStateOf<TransactionEntity?>(null) }
    var security by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(page == 0, { page = 0 }, { Text("🏠") }, label = { Text("Jalqaba") })
                NavigationBarItem(page == 1, { page = 1 }, { Text("📋") }, label = { Text("Seenaa") })
                NavigationBarItem(page == 2, { page = 2 }, { Text("➕") }, label = { Text("Galmeessi") })
                NavigationBarItem(page == 3, { page = 3 }, { Text("📊") }, label = { Text("Gabaasa") })
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (page) {
                0 -> Dashboard(transactions, vm) { security = true }
                1 -> History(transactions) { edit = it }
                2 -> Form { vm.save(it); page = 1 }
                3 -> Reports(transactions, vm)
            }
            edit?.let { item ->
                EditDialog(
                    item,
                    { vm.save(it); edit = null },
                    { vm.delete(it); edit = null }
                )
            }
            if (security) SecuritySettings(PinStore(context)) { security = false }
        }
    }
}

@Composable
fun PinLockScreen(onUnlock: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { PinStore(context) }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("🔐 FALMATAA CASH BOOK", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("PIN kee galchi")
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { if (it.all(Char::isDigit) && it.length <= 6) { pin = it; error = false } },
            label = { Text("PIN") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        if (error) Text("PIN sirrii miti", color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { if (store.verify(pin)) onUnlock() else error = true },
            enabled = pin.length in 4..6,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Seeni") }
    }
}

@Composable
fun SecuritySettings(store: PinStore, onClose: () -> Unit) {
    var setPin by remember { mutableStateOf(false) }
    if (setPin) {
        SetPinDialog(store) { setPin = false }
    } else {
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text("Nageenya") },
            text = { Text(if (store.enabled()) "PIN yeroo app banuutti gaafata." else "PIN app kee eeguuf dandeessisa.") },
            confirmButton = {
                if (store.enabled()) TextButton({ store.disable(); onClose() }) { Text("PIN cufi") }
                else TextButton({ setPin = true }) { Text("PIN qopheessi") }
            },
            dismissButton = { TextButton(onClose) { Text("Cufi") } }
        )
    }
}

@Composable
fun SetPinDialog(store: PinStore, onDone: () -> Unit) {
    var first by remember { mutableStateOf("") }
    var second by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDone,
        title = { Text("PIN qopheessi") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(first, { if (it.all(Char::isDigit) && it.length <= 6) first = it }, label = { Text("PIN haaraa") }, singleLine = true)
                OutlinedTextField(second, { if (it.all(Char::isDigit) && it.length <= 6) second = it }, label = { Text("PIN irra deebi'i") }, singleLine = true)
                if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton({
                when {
                    first.length !in 4..6 -> error = "PIN 4–6 lakkoofsa qabaachuu qaba"
                    first != second -> error = "PIN wal hin fakkaatu"
                    else -> { store.setPin(first); onDone() }
                }
            }) { Text("Olkaa'i") }
        },
        dismissButton = { TextButton(onDone) { Text("Haqi") } }
    )
}

@Composable
fun Dashboard(xs: List<TransactionEntity>, vm: CashBookViewModel, onSecurity: () -> Unit) {
    val day = startOfDay(System.currentTimeMillis())
    val month = startOfMonth(System.currentTimeMillis())
    val today = xs.filter { it.date >= day }
    val thisMonth = xs.filter { it.date >= month }
    fun sum(items: List<TransactionEntity>, type: String) = items.filter { it.type == type }.sumOf { it.amount }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("FALMATAA CASH BOOK", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Herrega kee salphatti to'adhu")
                }
                TextButton(onSecurity) { Text("⚙️") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("Hafe Waliigalaa")
                    Text(fmt(vm.balance(xs)) + " Birrii", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { SummaryCard("Galii Har'aa", sum(today, "Galii")) }
        item { SummaryCard("Baasii Har'aa", sum(today, "Baasii")) }
        item { SummaryCard("Galii Ji'aa", sum(thisMonth, "Galii")) }
        item { SummaryCard("Baasii Ji'aa", sum(thisMonth, "Baasii")) }
        item { SummaryCard("Baankii", vm.balance(xs, "Baankii")) }
        item { SummaryCard("Harkaa", vm.balance(xs, "Harkaa")) }
    }
}

@Composable
fun SummaryCard(title: String, amount: Long) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(fmt(amount) + " Birrii", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun History(xs: List<TransactionEntity>, onEdit: (TransactionEntity) -> Unit) {
    var query by remember { mutableStateOf("") }
    var selectedDay by remember { mutableStateOf<Long?>(null) }
    val filtered = xs.filter { t ->
        (t.description.contains(query, true) || t.type.contains(query, true) || t.account.contains(query, true) || fmt(t.amount).contains(query)) &&
            (selectedDay == null || startOfDay(t.date) == selectedDay)
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Seenaa Galmee", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Barbaadi") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = {
                    showDatePicker(androidx.compose.ui.platform.LocalContext.current) { selectedDay = startOfDay(it) }
                },
                modifier = Modifier.weight(1f)
            ) { Text(selectedDay?.let(::date) ?: "Guyyaa filadhu") }
            if (selectedDay != null) TextButton({ selectedDay = null }) { Text("Qulqulleessi") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(filtered, key = { it.id }) { t ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(t.type, fontWeight = FontWeight.Bold)
                            Text(if (t.description.isBlank()) "Ibsa hin jirre" else t.description)
                            Text(t.account + " • " + date(t.date), style = MaterialTheme.typography.bodySmall)
                        }
                        Text((if (t.type == "Galii") "+" else "-") + fmt(t.amount))
                        TextButton({ onEdit(t) }) { Text("Sirreessi") }
                    }
                }
            }
        }
    }
}

@Composable
fun Form(save: (TransactionEntity) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Galii") }
    var desc by remember { mutableStateOf("") }
    var account by remember { mutableStateOf("Harkaa") }
    var selectedDate by remember { mutableStateOf(startOfDay(System.currentTimeMillis())) }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (type == "Galii") "Galii Galmeessi" else "Baasii Galmeessi", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Maallaqa") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(type == "Galii", { type = "Galii" }, label = { Text("Galii") })
            FilterChip(type == "Baasii", { type = "Baasii" }, label = { Text("Baasii") })
        }
        OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth(), label = { Text("Ibsa") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(account == "Harkaa", { account = "Harkaa" }, label = { Text("Harkaa") })
            FilterChip(account == "Baankii", { account = "Baankii" }, label = { Text("Baankii") })
        }
        val context = androidx.compose.ui.platform.LocalContext.current
        OutlinedButton({ showDatePicker(context) { selectedDate = startOfDay(it) } }, Modifier.fillMaxWidth()) { Text("Guyyaa: ${date(selectedDate)}") }
        Button(
            onClick = {
                amount.toLongOrNull()?.takeIf { it > 0 }?.let {
                    save(TransactionEntity(0, it, type, desc.trim(), selectedDate, account))
                    amount = ""
                    desc = ""
                }
            },
            enabled = amount.toLongOrNull()?.let { it > 0 } == true,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Olkaa'i") }
    }
}

@Composable
fun EditDialog(t: TransactionEntity, save: (TransactionEntity) -> Unit, del: (TransactionEntity) -> Unit) {
    var amount by remember(t.id) { mutableStateOf(t.amount.toString()) }
    var type by remember(t.id) { mutableStateOf(t.type) }
    var desc by remember(t.id) { mutableStateOf(t.description) }
    var account by remember(t.id) { mutableStateOf(t.account) }
    var selectedDate by remember(t.id) { mutableStateOf(t.date) }
    var confirmDelete by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current

    AlertDialog(
        onDismissRequest = {},
        title = { Text("Galmee Sirreessi") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Maallaqa") }, singleLine = true)
                OutlinedTextField(desc, { desc = it }, label = { Text("Ibsa") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == "Galii", { type = "Galii" }, label = { Text("Galii") })
                    FilterChip(type == "Baasii", { type = "Baasii" }, label = { Text("Baasii") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(account == "Harkaa", { account = "Harkaa" }, label = { Text("Harkaa") })
                    FilterChip(account == "Baankii", { account = "Baankii" }, label = { Text("Baankii") })
                }
                OutlinedButton({ showDatePicker(context) { selectedDate = startOfDay(it) } }, Modifier.fillMaxWidth()) { Text("Guyyaa: ${date(selectedDate)}") }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                amount.toLongOrNull()?.takeIf { it > 0 }?.let {
                    save(t.copy(amount = it, type = type, description = desc.trim(), account = account, date = selectedDate))
                }
            }) { Text("Olkaa'i") }
        },
        dismissButton = { TextButton({ confirmDelete = true }) { Text("Haqi") } }
    )

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Galmee haqxuu?") },
            text = { Text("Galmeen kun guutummaatti ni haqama.") },
            confirmButton = { TextButton({ del(t) }) { Text("Eeyyee, Haqi") } },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("Lakki") } }
        )
    }
}

@Composable
fun Reports(xs: List<TransactionEntity>, vm: CashBookViewModel) {
    val now = System.currentTimeMillis()
    val day = startOfDay(now)
    val week = startOfWeek(now)
    val month = startOfMonth(now)
    val tomorrow = startOfDay(addDays(now, 1))
    val nextWeek = startOfWeek(addDays(now, 7))
    val nextMonth = startOfMonth(addMonths(now, 1))

    fun total(from: Long, to: Long, type: String) = xs.filter { it.date >= from && it.date < to && it.type == type }.sumOf { it.amount }
    val dg = total(day, tomorrow, "Galii"); val db = total(day, tomorrow, "Baasii")
    val wg = total(week, nextWeek, "Galii"); val wb = total(week, nextWeek, "Baasii")
    val mg = total(month, nextMonth, "Galii"); val mb = total(month, nextMonth, "Baasii")

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Gabaasa", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Galii fi baasii yeroo adda addaatiin") }
        item { ReportCard("Har'aa", dg, db) }
        item { ReportCard("Torban kanaa", wg, wb) }
        item { ReportCard("Ji'a kanaa", mg, mb) }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("Hafe Waliigalaa", fontWeight = FontWeight.Bold); Text(fmt(vm.balance(xs)) + " Birrii", style = MaterialTheme.typography.titleLarge) } } }
        item { BackupExportSection(xs, vm) }
    }
}

@Composable
fun BackupExportSection(xs: List<TransactionEntity>, vm: CashBookViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var pending by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var restoring by remember { mutableStateOf(false) }
    var restorePayload by remember { mutableStateOf<List<TransactionEntity>?>(null) }

    val create = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    when (pending) {
                        "backup" -> writeBackup(out, xs)
                        "csv" -> writeCsv(out, xs)
                        "pdf" -> writePdf(out, xs)
                    }
                }
                message = "Faayiliin milkaa'inaan olkaa'ame."
            } catch (_: Exception) {
                message = "Faayilii uumuu hin dandeenye."
            }
        }
    }

    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val data = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalArgumentException()
                val arr = JSONObject(data).getJSONArray("transactions")
                val list = buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(TransactionEntity(
                            id = o.optLong("id", 0L), amount = o.getLong("amount"),
                            type = o.getString("type"), description = o.optString("description", ""),
                            date = o.getLong("date"), account = o.getString("account")
                        ))
                    }
                }
                restorePayload = list
                restoring = true
            } catch (_: Exception) {
                message = "Backup sirrii miti ykn banamuu hin dandeenye."
            }
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Backup fi Export", fontWeight = FontWeight.Bold)
            Text("Galmee kee faayiliitti olkaa'i ykn gara PDF/CSV baasi.")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ pending = "backup"; create.launch("FALMATAA_CASH_BOOK_Backup.json") }, Modifier.weight(1f)) { Text("💾 Backup") }
                Button({ open.launch(arrayOf("application/json", "text/json")) }, Modifier.weight(1f)) { Text("↩ Restore") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ pending = "pdf"; create.launch("FALMATAA_CASH_BOOK_Report.pdf") }, Modifier.weight(1f)) { Text("📄 PDF") }
                Button({ pending = "csv"; create.launch("FALMATAA_CASH_BOOK.csv") }, Modifier.weight(1f)) { Text("📊 Excel/CSV") }
            }
            if (message.isNotEmpty()) Text(message, color = MaterialTheme.colorScheme.primary)
        }
    }

    if (restoring && restorePayload != null) {
        AlertDialog(
            onDismissRequest = { restoring = false },
            title = { Text("Backup deebisuu?") },
            text = { Text("Galmee amma jiru bakka buusa. ${restorePayload!!.size} galmee backup keessaa jira.") },
            confirmButton = {
                TextButton({ vm.clearAndRestore(restorePayload!!); restoring = false; message = "Backup deebifame." }) { Text("Eeyyee") }
            },
            dismissButton = { TextButton({ restoring = false }) { Text("Lakki") } }
        )
    }
}

@Composable
fun ReportCard(title: String, income: Long, expense: Long) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text("Galii: ${fmt(income)} Birrii")
            Text("Baasii: ${fmt(expense)} Birrii")
            Text("Hafe: ${fmt(income - expense)} Birrii", fontWeight = FontWeight.Bold)
        }
    }
}

fun writeBackup(out: OutputStream, xs: List<TransactionEntity>) {
    val root = JSONObject().apply {
        put("app", "FALMATAA CASH BOOK")
        put("version", 2)
        put("created", System.currentTimeMillis())
        put("transactions", JSONArray().apply {
            xs.forEach { t -> put(JSONObject().apply {
                put("id", t.id); put("amount", t.amount); put("type", t.type)
                put("description", t.description); put("date", t.date); put("account", t.account)
            }) }
        })
    }
    out.write(root.toString(2).toByteArray(StandardCharsets.UTF_8))
}

fun writeCsv(out: OutputStream, xs: List<TransactionEntity>) {
    val sb = StringBuilder("\uFEFFID,Maallaqa,Gosa,Ibsa,Guyyaa,Bakka Maallaqaa\n")
    xs.forEach { t ->
        sb.append(t.id).append(',').append(t.amount).append(',')
            .append(csv(t.type)).append(',').append(csv(t.description)).append(',')
            .append(csv(date(t.date))).append(',').append(csv(t.account)).append('\n')
    }
    out.write(sb.toString().toByteArray(StandardCharsets.UTF_8))
}

fun csv(value: String): String = "\"${value.replace("\"", "\"\"")}\""

fun writePdf(out: OutputStream, xs: List<TransactionEntity>) {
    val doc = PdfDocument()
    val width = 595
    val height = 842
    val rowsPerPage = 38
    val pages = maxOf(1, (xs.size + rowsPerPage - 1) / rowsPerPage)

    for (pageNumber in 0 until pages) {
        val page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, pageNumber + 1).create())
        val canvas = page.canvas
        val title = Paint().apply { textSize = 18f; isFakeBoldText = true }
        val text = Paint().apply { textSize = 10f }
        canvas.drawText("FALMATAA CASH BOOK", 32f, 40f, title)
        canvas.drawText("Seenaa Galmee • Fuula ${pageNumber + 1}/$pages", 32f, 62f, text)

        var y = 88f
        val start = pageNumber * rowsPerPage
        val end = minOf(xs.size, start + rowsPerPage)
        for (i in start until end) {
            val t = xs[i]
            canvas.drawText("${i + 1}. ${date(t.date)}  ${t.type}  ${t.account}  ${fmt(t.amount)} Birrii", 32f, y, text)
            if (t.description.isNotBlank()) canvas.drawText(t.description.take(70), 55f, y + 13f, text)
            y += if (t.description.isBlank()) 18f else 31f
        }
        doc.finishPage(page)
    }
    doc.writeTo(out)
    doc.close()
}

fun showDatePicker(context: Context, onSelected: (Long) -> Unit) {
    val cal = Calendar.getInstance()
    DatePickerDialog(
        context,
        { _, year, month, day ->
            Calendar.getInstance().apply {
                set(year, month, day, 0, 0, 0)
                set(Calendar.MILLISECOND, 0)
                onSelected(timeInMillis)
            }
        },
        cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
    ).show()
}

fun startOfDay(ms: Long): Long = Calendar.getInstance().apply {
    timeInMillis = ms; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun startOfMonth(ms: Long): Long = Calendar.getInstance().apply {
    timeInMillis = ms; set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun startOfWeek(ms: Long): Long = Calendar.getInstance().apply {
    timeInMillis = ms
    firstDayOfWeek = Calendar.MONDAY
    set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun addDays(ms: Long, days: Int): Long = Calendar.getInstance().apply { timeInMillis = ms; add(Calendar.DAY_OF_YEAR, days) }.timeInMillis
fun addMonths(ms: Long, months: Int): Long = Calendar.getInstance().apply { timeInMillis = ms; add(Calendar.MONTH, months) }.timeInMillis
fun fmt(n: Long): String = String.format(Locale.US, "%,d", n)
fun date(ms: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(ms))
